import WalletConnect from "@walletconnect/web3-provider";

export const providerOptions = {
 
  walletconnect: {
    package: WalletConnect, // required
    options: {
      infuraId: 'f0f2fca1dc5d6586c0ae7e0650b649b8' // required
    }
  }
};



